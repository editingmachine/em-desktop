'use strict';

// Older consumers (ESLint, asar, dir-compare and filelist) expect a callable
// CommonJS export. All matching still runs in patched upstream minimatch.
module.exports = require('minimatch').minimatch;
