'use strict';

const upstream = require('glob');

// rimraf 3 and asar 3 use callbacks (including util.promisify). Keep their
// calling convention without retaining glob's vulnerable traversal engine.
function glob(pattern, options, callback) {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }
  const result = upstream.glob(pattern, options || {});
  if (typeof callback === 'function') {
    result.then(matches => callback(null, matches), error => callback(error));
  }
  return result;
}

Object.assign(glob, upstream, { glob, sync: upstream.globSync });
module.exports = glob;
